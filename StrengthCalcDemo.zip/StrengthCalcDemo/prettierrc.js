module.exports = {
    bracketSpacing: true,
    jsxBracketSameLine: false,
    singleQuote: true,
    trailingComma: 'all',
    htmlWhitespaceSensitivity: "ignore",
    semi: false
  };