// Inside vue.config.js
module.exports = {
    runtimeCompiler: true,
    // ...other vue-cli plugin options...
    pwa: {
        workboxOptions:{
            exclude: [/\.config$/, /\.map$/]
      }
    }
  }
