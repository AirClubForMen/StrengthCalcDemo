import Vue from "vue";
import VueRouter from "vue-router";
import { store } from "../store/index.js";

Vue.use(VueRouter);

const routes = [
  {
    path: "/",
    name: "Settings",
    component: () => import("../components/Settings.vue"),
    meta: { requiresAuth: false },
  },
    {
        path: "/*",
        name: "Settings",
        component: () => import("../components/Settings.vue"),
        meta: { requiresAuth: false },
    }, 
  {
    path: "/settings",
    name: "Settings",
    component: () => import("../components/Settings.vue"),
      meta: { requiresAuth: false },
  },  
];

const router = new VueRouter({
  mode: "hash",
  base: process.env.BASE_URL,
  routes,
});

router.beforeEach((to, from, next) => {
  if (to.matched.some((record) => record.meta.requiresAuth)) {
    if (store.getters.isAuthenticated) {
      next();
      return;
    }
    next("/");
  } else {
    next();
  }
});

export default router;
