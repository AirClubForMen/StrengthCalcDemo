import axios from "axios";

export default {
  validateLicense(licenseKey, emailId, deviceId, deviceModel) {
    let url = process.env.VUE_APP_BASE_URL + "validateLicenseWithEmailnKey";

    return axios.get(
      url +
        "?licenseKey=" +
        licenseKey +
        "&emailId=" +
        emailId +
        "&deviceId=" +
        deviceId +
        "&deviceModel=" +
        deviceModel
    );
  },

  getLicenseDetails(licenseKey, emailId) {
    let url = process.env.VUE_APP_BASE_URL + "getLicenceDetailsByEmailnKey";

    return axios.get(url + "?licenseKey=" + licenseKey + "&emailId=" + emailId);
  },

  addDeviceMatrix(payload) {
    let url = process.env.VUE_APP_BASE_URL + "AddDeviceMatrix";

    return axios.post(url, payload);
  },
};
